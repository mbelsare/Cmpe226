﻿-- Function: _2_3_mesowest_insert_wind()

-- DROP FUNCTION _2_3_mesowest_insert_wind();

CREATE OR REPLACE FUNCTION _2_3_mesowest_insert_wind()
  RETURNS void AS
$BODY$
DECLARE
	row record;
	row_found boolean;
	_uniqueid bigint;
	_sknt real;
	_drct real;
	_gust real;
BEGIN
	EXECUTE 'SELECT EXISTS (SELECT * FROM _PROCESSED_COUNT WHERE step=3);' INTO row_found;
	IF (row_found) THEN
		row_found:=false;
		FOR row IN 
			SELECT dim_key_id,sknt, drct, gust  FROM stg_weather
		LOOP
			IF row.sknt<>-9999 OR row.drct<>-9999 OR row.gust<>-9999 THEN
				EXECUTE 'SELECT uniqueid, speed, direction, gust FROM wind_curr WHERE uniqueid=$1;' USING row.dim_key_id INTO _uniqueid, _sknt, _drct, _gust;
				IF (_uniqueid IS NOT NULL) THEN
					IF (round(row.sknt::numeric,2)<>round(_sknt::numeric,2) OR round(row.drct::numeric,2)<>round(_drct::numeric,2) OR round(row.gust::numeric,2)<>round(_gust::numeric,2)) THEN
						EXECUTE 'UPDATE wind_curr SET speed=$1, direction=$2, gust=$3 WHERE uniqueid=$4;' USING row.sknt,row.drct,row.gust, row.dim_key_id;
						--RAISE INFO '---Row Updated for %',row.dim_key_id;
					--ELSE
						--RAISE INFO '*** No Update Required For %',row.dim_key_id;
					END IF;
				ELSE
					EXECUTE 'INSERT INTO wind_curr values ($1, $2, $3, $4);' USING row.dim_key_id, row.sknt, row.drct, row.gust;
					--RAISE INFO 'Row Inserted for %',row.dim_key_id;
				END IF;
			END IF;
		END LOOP;
		EXECUTE 'UPDATE _processed_count set step=4;';
	ELSE
		RAISE EXCEPTION 'Please run the processes in order';
	END IF;
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION _2_3_mesowest_insert_wind()
  OWNER TO postgres;
