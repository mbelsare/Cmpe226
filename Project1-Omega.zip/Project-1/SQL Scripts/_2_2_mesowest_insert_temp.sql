﻿-- Function: _2_2_mesowest_insert_temp()

-- DROP FUNCTION _2_2_mesowest_insert_temp();

CREATE OR REPLACE FUNCTION _2_2_mesowest_insert_temp()
  RETURNS void AS
$BODY$
DECLARE
	row record;
	row_found boolean;
	_uniqueid bigint;
	_temp real;
BEGIN
	EXECUTE 'SELECT EXISTS (SELECT * FROM _PROCESSED_COUNT WHERE step=2);' INTO row_found;
	IF (row_found) THEN
		row_found:=false;
		FOR row IN 
			SELECT dim_key_id, tmpf FROM stg_weather 
		LOOP
			IF row.tmpf<>-9999 THEN
				EXECUTE '(SELECT uniqueid, temp FROM temp_curr WHERE uniqueid=$1);' USING row.dim_key_id INTO _uniqueid,_temp ;
				IF (_uniqueid IS NOT NULL) THEN
					IF (round(_temp::numeric,2)<>round(row.tmpf::numeric,2)) THEN
						EXECUTE 'UPDATE temp_curr SET temp=$1 WHERE uniqueid=$2;' USING row.tmpf, row.dim_key_id;
						--RAISE INFO '--- Row Updated for %',row.dim_key_id;
					--ELSE
						--RAISE INFO '*** No update Required for % ***',row.dim_key_id;
					END IF;
				ELSE
					EXECUTE 'INSERT INTO temp_curr values ($1, $2);' USING row.dim_key_id, row.tmpf;
					--RAISE INFO 'Row Inserted for %',row.dim_key_id;
				END IF;
			END IF;
		END LOOP;
		EXECUTE 'UPDATE _processed_count set step=3;';
	ELSE
		RAISE EXCEPTION 'Please run the processes in order';
	END IF;
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION _2_2_mesowest_insert_temp()
  OWNER TO postgres;
