﻿-- Function: _2_4_mesowest_insert_humidity()

-- DROP FUNCTION _2_4_mesowest_insert_humidity();

CREATE OR REPLACE FUNCTION _2_4_mesowest_insert_humidity()
  RETURNS void AS
$BODY$
DECLARE
	row record;
	row_found boolean;
	_uniqueid bigint;
	_dwpf real;
	_relh real;

BEGIN
	EXECUTE 'SELECT EXISTS (SELECT * FROM _PROCESSED_COUNT WHERE step=4);' INTO row_found;
	IF (row_found) THEN
		row_found:=false;
		FOR row IN 
			SELECT dim_key_id,dwpf, relh  FROM stg_weather
		LOOP
			IF row.dwpf<>-9999 OR row.relh<>-9999 THEN
				EXECUTE 'SELECT uniqueid, dewpoint, rel_hum FROM humidity_curr WHERE uniqueid=$1;' USING row.dim_key_id INTO _uniqueid, _dwpf, _relh;
				IF (_uniqueid IS NOT NULL) THEN
					IF(round(_dwpf::numeric,2)<>round(row.dwpf::numeric,2) OR round(_relh::numeric,2)<>round(row.relh::numeric,2)) THEN
						EXECUTE 'UPDATE humidity_curr SET dewpoint=$1, rel_hum=$2 WHERE uniqueid=$3;' USING row.dwpf,row.relh,row.dim_key_id;
						RAISE INFO '---Row Updated for %',row.dim_key_id;
					ELSE
						RAISE INFO '*** No Row Update Required for % ***',row.dim_key_id;
					END IF;
				ELSE
					EXECUTE 'INSERT INTO humidity_curr values ($1, $2, $3);' USING row.dim_key_id, row.dwpf, row.relh;
					RAISE INFO 'Row Inserted for %',row.dim_key_id;
				END IF;
			END IF;
		END LOOP;
		EXECUTE 'UPDATE _processed_count set step=5;';
	ELSE
		RAISE EXCEPTION 'Please run the processes in order';
	END IF;
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION _2_4_mesowest_insert_humidity()
  OWNER TO postgres;
