﻿-- Function: _2_1_mesowest_insert_dim_key()

-- DROP FUNCTION _2_1_mesowest_insert_dim_key();

CREATE OR REPLACE FUNCTION _2_1_mesowest_insert_dim_key()
  RETURNS void AS
$BODY$
DECLARE
	row record;
	_uniqueid bigint;
BEGIN
	IF (SELECT EXISTS (SELECT * FROM _PROCESSED_COUNT WHERE step=1)) THEN
		-- Insert cleaned rows into _dim_key
		FOR row IN 
			SELECT stn, _date, _time, row_id FROM stg_weather
		LOOP
			EXECUTE 'SELECT unique_id FROM dim_key_curr WHERE stn_id=$1 and _date=$2 and _time=$3;' USING row.stn, row._date, row._time INTO _uniqueid;
			IF (_uniqueid is null) THEN
				-- Insert row into dim_key_curr table
				EXECUTE 'INSERT INTO dim_key_curr (stn_id, _date, _time) values ($1, $2, $3);' 
				USING row.stn, row._date, row._time;
				--RAISE INFO 'Inserted Row %',row.row_id;
			ELSE
				-- Update staging with the key_id from dim_key_curr
				EXECUTE 'UPDATE stg_weather set dim_key_id=$1 where row_id=$2;' USING _uniqueid, row.row_id;
				--RAISE INFO '--- Row Updated %',row.row_id;
			END IF;
		END LOOP;

		-- update staging with the row_ids from dim_key_curr for the new records
		WITH updrec as ((
		select unique_id, stn_id, _date, _time FROM dim_key_curr
		WHERE unique_id>(select counter_key from _processed_count))
		) 
		UPDATE stg_weather s1 
		SET dim_key_id = updrec.unique_id
		FROM updrec 
		WHERE s1.stn=updrec.stn_id AND s1._date=updrec._date AND s1._time=updrec._time;

		-- update processed row count
		UPDATE _processed_count set counter_key=(SELECT MAX(unique_id) from dim_key_curr);
		UPDATE _processed_count set step=2;
	ELSE
		RAISE EXCEPTION 'Please run the processes in order';
	END IF;
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION _2_1_mesowest_insert_dim_key()
  OWNER TO postgres;
