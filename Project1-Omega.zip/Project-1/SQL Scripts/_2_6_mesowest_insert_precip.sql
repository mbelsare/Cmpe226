﻿-- Function: _2_6_mesowest_insert_precip()

-- DROP FUNCTION _2_6_mesowest_insert_precip();

CREATE OR REPLACE FUNCTION _2_6_mesowest_insert_precip()
  RETURNS void AS
$BODY$
DECLARE
	row record;
	row_found boolean;
	_uniqueid bigint;
	_p24i real;
BEGIN
	EXECUTE 'SELECT EXISTS (SELECT * FROM _PROCESSED_COUNT WHERE step=6);' INTO row_found;
	IF (row_found) THEN
		row_found:=false;
		FOR row IN 
			SELECT dim_key_id,_date, stn, p24i  FROM stg_weather
		LOOP
			IF row.p24i<>-9999 THEN
				EXECUTE 'SELECT uniqueid, p24i FROM precip_curr WHERE uniqueid=$1;' USING row.dim_key_id INTO _uniqueid, _p24i;
				IF (_uniqueid IS NOT NULL) THEN
					IF (round(_p24i::numeric,2)<>round(row.p24i::numeric,2)) THEN
						EXECUTE 'UPDATE precip_curr SET p24i=$1, _date= $2, stn_id=$3 WHERE uniqueid=$4;' USING row.p24i,row._date,row.stn,row.dim_key_id;
						RAISE INFO '--- Row Updated for %',row.dim_key_id;
					ELSE
						RAISE INFO '*** No Row Update Required for % ***',row.dim_key_id;
					END IF;
				ELSE
					EXECUTE 'INSERT INTO precip_curr values ($1, $2, $3, $4);' USING row.dim_key_id, row._date, row.stn, row.p24i;
					RAISE INFO 'Row Inserted for %',row.dim_key_id;
				END IF;
			END IF;
		END LOOP;
		EXECUTE 'UPDATE _processed_count set step=1;';
		EXECUTE 'UPDATE _processed_count set counter=(select max(row_id) from stg_weather);';
		EXECUTE 'TRUNCATE stg_weather;';
		
	ELSE
		RAISE EXCEPTION 'Please run the processes in order';
	END IF;
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION _2_6_mesowest_insert_precip()
  OWNER TO postgres;
