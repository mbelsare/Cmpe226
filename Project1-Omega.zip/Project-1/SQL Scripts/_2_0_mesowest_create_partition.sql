﻿-- Function: _2_0_mesowest_create_partition(date)

-- DROP FUNCTION _2_0_mesowest_create_partition(date);

CREATE OR REPLACE FUNCTION _2_0_mesowest_create_partition(_date date)
  RETURNS void AS
$BODY$
DECLARE
	
	_uniqueid bigint;
	_year integer;
	_week integer;
	_suffix text;
	_mindate text;
	_maxdate text;
	_minid bigint;
	_maxid bigint;
BEGIN
	-- Ensure that the date entered is a Monday
	IF(EXTRACT(DOW from _date)=1) THEN
		-- Prevent other procedures from running until this completes. 
		EXECUTE 'UPDATE _processed_count set step=0;';
		_year:=EXTRACT (year from _date);
		_week:=EXTRACT (WEEK from _date); 
		_suffix:=_year::text||'_'||_week::text;

		EXECUTE 'SELECT MIN(_date), MAX(_date), MIN(unique_id), MAX(unique_id) FROM dim_key_curr' INTO _mindate, _maxdate, _minid, _maxid;
		
		-- Move data from XX_curr to XX_year_week
		RAISE INFO '1. Moving Tables---';
		EXECUTE 'ALTER TABLE dim_key_curr RENAME TO dim_key_' ||_suffix|| ';';
		EXECUTE 'ALTER TABLE dim_key_' || _suffix || ' ADD CONSTRAINT '||quote_ident('C_dim_key_' || _suffix) ||' CHECK (_date >= ' || quote_literal(_mindate) || ' and _date <= ' ||quote_literal(_maxdate) || ' and unique_id >= '||_minid ||' and unique_id<= '||_maxid || ' );';
		RAISE INFO '--- Moved dim_key ---';
		EXECUTE 'ALTER TABLE humidity_curr RENAME TO humidity_' ||_suffix|| ';';
		EXECUTE 'ALTER TABLE humidity_' || _suffix || ' ADD CONSTRAINT '||quote_ident('C_humidity_' || _suffix) ||' CHECK (uniqueid >= '||_minid ||' and uniqueid<= '||_maxid || ' );';
		RAISE INFO '--- Moved humidity ---';
		EXECUTE 'ALTER TABLE precip_curr RENAME TO precip_' ||_suffix|| ';';
		EXECUTE 'ALTER TABLE precip_' || _suffix || ' ADD CONSTRAINT '||quote_ident('C_precip' || _suffix) ||' CHECK (_date >= ' || quote_literal(_mindate) || ' and _date <= ' ||quote_literal(_maxdate) || ' and uniqueid >= '||_minid ||' and uniqueid<= '||_maxid || ' );';
		RAISE INFO '--- Moved precip ---';
		EXECUTE 'ALTER TABLE pressure_curr RENAME TO pressure_' ||_suffix|| ';';
		EXECUTE 'ALTER TABLE pressure_' || _suffix || ' ADD CONSTRAINT '||quote_ident('C_pressure_' || _suffix) ||' CHECK (uniqueid >= '||_minid ||' and uniqueid<= '||_maxid || ' );';
		RAISE INFO '--- Moved pressure ---';
		EXECUTE 'ALTER TABLE temp_curr RENAME TO temp_' ||_suffix|| ';';
		EXECUTE 'ALTER TABLE temp_' || _suffix || ' ADD CONSTRAINT '||quote_ident('C_temp_' || _suffix) ||' CHECK (uniqueid >= '||_minid ||' and uniqueid<= '||_maxid || ' );';
		RAISE INFO '--- Moved temp ---';
		EXECUTE 'ALTER TABLE wind_curr RENAME TO wind_' ||_suffix|| ';';
		EXECUTE 'ALTER TABLE wind_' || _suffix || ' ADD CONSTRAINT '||quote_ident('C_wind_' || _suffix) ||' CHECK (uniqueid >= '||_minid ||' and uniqueid<= '||_maxid || ' );';
		RAISE INFO ' --- Move Completed';

		-- Set up new constraint values
		_minid:=_maxid+1;

		-- Create new tables and indexes
		RAISE INFO '2. Creating new tables---';
		EXECUTE 'CREATE TABLE dim_key_curr (PRIMARY KEY (unique_id)) INHERITS (_dim_key);';
		EXECUTE 'CREATE INDEX ON dim_key_curr USING btree (stn_id COLLATE pg_catalog."default", _date, _time);';
		EXECUTE 'ALTER TABLE dim_key_curr ADD CONSTRAINT '||quote_ident('C_dim_curr_' || _suffix) ||' CHECK (unique_id >= '||_minid ||' );';
		RAISE INFO '--- Created dim_key_curr';
		EXECUTE 'CREATE TABLE temp_curr (PRIMARY KEY (uniqueid)) INHERITS (_temp);';
		EXECUTE 'CREATE INDEX ON temp_curr USING btree (temp);';
		EXECUTE 'ALTER TABLE temp_curr ADD CONSTRAINT '||quote_ident('C_temp_curr_' || _suffix) ||' CHECK (uniqueid >= '||_minid ||' );';
		RAISE INFO '--- Created temp_curr';
		EXECUTE 'CREATE TABLE humidity_curr (PRIMARY KEY (uniqueid)) INHERITS (_humidity);';
		EXECUTE 'ALTER TABLE humidity_curr ADD CONSTRAINT '||quote_ident('C_humidity_curr_' || _suffix) ||' CHECK (uniqueid >= '||_minid ||' );';
		RAISE INFO '--- Created humidity_curr';
		EXECUTE 'CREATE TABLE precip_curr (PRIMARY KEY (uniqueid)) INHERITS (_precip);';
		EXECUTE 'ALTER TABLE precip_curr ADD CONSTRAINT '||quote_ident('C_precip_curr_' || _suffix) ||' CHECK (uniqueid >= '||_minid ||' );';
		RAISE INFO '--- Created precip_curr';
		EXECUTE 'CREATE TABLE pressure_curr (PRIMARY KEY (uniqueid)) INHERITS (_pressure);';
		EXECUTE 'ALTER TABLE pressure_curr ADD CONSTRAINT '||quote_ident('C_pressure_curr_' || _suffix) ||' CHECK (uniqueid >= '||_minid ||' );';
		RAISE INFO '--- Created pressure_curr';
		EXECUTE 'CREATE TABLE wind_curr (PRIMARY KEY (uniqueid)) INHERITS (_wind);';
		EXECUTE 'ALTER TABLE wind_curr ADD CONSTRAINT '||quote_ident('C_wind_curr_' || _suffix) ||' CHECK (uniqueid >= '||_minid ||' );';
	        RAISE INFO '--- Created wind_curr';

		-- Allow other procedures to run 
		EXECUTE 'UPDATE _processed_count set step=1;';
	
	ELSE
		RAISE EXCEPTION '***** Please enter a date which falls on a Monday ****';
	END IF;
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION _2_0_mesowest_create_partition(date)
  OWNER TO postgres;
