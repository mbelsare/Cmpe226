﻿-- Function: _mesowest_drct(real)

-- DROP FUNCTION _mesowest_drct(real);

CREATE OR REPLACE FUNCTION _mesowest_drct(_drct real)
  RETURNS text AS
$BODY$
DECLARE
	dirtable text[] = ARRAY['N','NNE','NE','ENE','E','ESE', 'SE','SSE','S','SSW','SW','WSW', 'W','WNW','NW','NNW','**N**'];
	
BEGIN
	RETURN dirtable[floor((((_drct+1)::int % 360) +11.25)/22.5)];
	
END;
$BODY$
  LANGUAGE plpgsql IMMUTABLE STRICT
  COST 100;
ALTER FUNCTION _mesowest_drct(real)
  OWNER TO postgres;
