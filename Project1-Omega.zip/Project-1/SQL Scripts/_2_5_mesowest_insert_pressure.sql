﻿-- Function: _2_5_mesowest_insert_pressure()

-- DROP FUNCTION _2_5_mesowest_insert_pressure();

CREATE OR REPLACE FUNCTION _2_5_mesowest_insert_pressure()
  RETURNS void AS
$BODY$
DECLARE
	row record;
	row_found boolean;
	_uniqueid bigint;
	_pmsl real;
	_alti real;
BEGIN
	EXECUTE 'SELECT EXISTS (SELECT * FROM _PROCESSED_COUNT WHERE step=5);' INTO row_found;
	IF (row_found) THEN
		row_found:=false;
		FOR row IN 
			SELECT dim_key_id,pmsl, alti  FROM stg_weather
		LOOP
			IF row.pmsl<>-9999 OR row.alti<>-9999 THEN
				EXECUTE 'SELECT uniqueid, pressure, altimeter FROM pressure_curr WHERE uniqueid=$1;' USING row.dim_key_id INTO _uniqueid, _pmsl, _alti;
				IF (_uniqueid IS NOT NULL) THEN
					IF(round(row.pmsl::numeric,2)<>round(_pmsl::numeric,2) OR round(row.alti::numeric,2)<>round(_alti::numeric,2)) THEN
						EXECUTE 'UPDATE pressure_curr SET pressure=$1, altimeter=$2 WHERE uniqueid=$3;' USING row.pmsl,row.alti,row.dim_key_id;
						RAISE INFO '---Row Updated for %',row.dim_key_id;
					ELSE
						RAISE INFO '*** No Update Required for % ***',row.dim_key_id;
					END IF;
				ELSE
					EXECUTE 'INSERT INTO pressure_curr values ($1, $2, $3);' USING row.dim_key_id, row.pmsl, row.alti;
					RAISE INFO 'Row Inserted for %',row.dim_key_id;
				END IF;
			END IF;
		END LOOP;
		EXECUTE 'UPDATE _processed_count set step=6;';
	ELSE
		RAISE EXCEPTION 'Please run the processes in order';
	END IF;
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION _2_5_mesowest_insert_pressure()
  OWNER TO postgres;
