#!/bin/bash
# download MESOWEST data
cd ~/Dropbox/CMPE226
if [ ! -d ./data ]; then
	mkdir data
fi

curl http://mesowest.utah.edu/data/mesowest.out.gz -o mesowest.gz
if [ -f ./mesowest.gz ]; then
	gunzip mesowest.gz
	tail -n +4 mesowest>mesowest_temp
	rm mesowest
	#cp mesowest_temp data/mesowest-$(date +%Y%m%d-%H.%M).txt
	#echo "Delimited File written"
	tail -n +2 mesowest_temp>mesowest_temp1
	rm mesowest_temp
	sed -i.bak -E 's/[ ][ ]*/,/g' mesowest_temp1
	sed -i.bak -E 's/,//' mesowest_temp1
	echo "Commas put"
	awk -F, '
		{
			split($2,a,""); 
			td=(a[1] a[2] a[3] a[4] "-" a[5] a[6] "-" a[7] a[8] "," a[10] a[11] ":" a[12] a[13] ":00");
			$2=td;
			print $0;
	}' OFS=, mesowest_temp1 >newfile.txt
	echo " Date Changed"
	awk -F "," '
	{ 
		for(i=1;i<=NF;i++) {
			if(i>=4 && i<NF){
				printf "%0.2f,", $i
			} 
			else if(i==NF){
				printf "%0.2f",$i
			} 
			else{
				printf $i;printf"," 
			}
		}; 
		printf "\n"  
	}' FS=',' newfile.txt > infile.txt
	echo " Decimals corrected Changed"
	
	rm mesowest_temp1.bak
	rm mesowest_temp1
	rm newfile.txt
	mv infile.txt data/mesowest-$(date +%Y%m%d-%H.%M).txt
	echo "CSV File written"
	pwd
fi

