package org.weather.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.util.Locale;
import java.sql.Timestamp;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

public class Weather implements Serializable{	

	private String station_id;
	private String date;
	private String time;
	private String mnet;
	private String slat;
	private String slon;
	private String selv;
	private String tmpf;
	private String sknt;
	private String drct;
	private String gust;
	private String pmsl;
	private String alti;
	private String dwpf;
	private String relh;
	private String wthr;
	private String p24i;
	
	public String getStation_id() {
		return station_id;
	}

	public void setStation_id(String station_id) {
		this.station_id = station_id;
	}
	
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}
	
	public String getMnet() {
		return mnet;
	}

	public void setMnet(String sMnet) {
		this.mnet = sMnet;
	}
	
	public String getSlat() {
		return slat;
	}

	public void setSlat(String sSlat) {
		this.slat = sSlat;
	}
		
	public String getSlon() {
		return slon;
	}

	public void setSlon(String sSlon) {
		this.slon = sSlon;
	}
	
	public String getSelv() {
		return selv;
	}

	public void setSelv(String sSelv) {
		this.selv = sSelv;
	}
	
	public String getTmpf() {
		return tmpf;
	}

	public void setTmpf(String sTmpf) {
		this.tmpf = sTmpf;
		
	}
	
	public String getSknt() {
		return sknt;
	}

	public void setSknt(String sSknt) {
		this.sknt = sSknt;
	}
	
	public String getDrct() {
		return drct;
	}

	public void setDrct(String sDrct) {
		this.drct = sDrct;
	}
	
	public String getGust() {
		return gust;
	}

	public void setGust(String sGust) {
		this.gust = sGust;
	}
	
	public String getPmsl() {
		return pmsl;
	}

	public void setPmsl(String sPmsl) {
		this.pmsl = sPmsl;
	}
	
	public String getAlti() {
		return alti;
	}

	public void setAlti(String sAlti) {
		this.alti = sAlti;
	}
	
	public String getDwpf() {
		return dwpf;
	}

	public void setDwpf(String sDwpf) {
		this.dwpf = sDwpf;
	}
	
	public String getRelh() {
		return relh;
	}

	public void setRelh(String sRelh) {
		this.relh = sRelh;
	}
	
	public String getWthr() {
		return wthr;
	}

	public void setWthr(String sWthr) {
		this.wthr = sWthr;
	}
	
	public String getP24i() {
		return p24i;
	}

	public void setP24i(String sP24i) {
		this.p24i = sP24i;
	}

	
	
}
