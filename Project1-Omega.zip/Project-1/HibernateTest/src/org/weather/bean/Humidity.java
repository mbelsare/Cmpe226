package org.weather.bean;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "_humidity")
public class Humidity implements Serializable{
	@Id
	@GeneratedValue
	@Column(name = "uniqueid")
	private long uniqueid;

	@Column(name = "dewpoint")
	private Float dewpoint;

	@Column(name = "rel_hum")
	private Float rel_hum;
	
	
	public long getUniqueId() {
		return uniqueid;
	}

	public void setUniqueId(long uniqueid) {
		this.uniqueid = uniqueid;
	}

	public Float getDewpoint() {
		return dewpoint;
	}

	public void setDewpoint(Float dewpoint) {
		this.dewpoint = dewpoint;
	}

	public Float getRel_hum() {
		return rel_hum;
	}

	public void setRel_hum(Float rel_hum) {
		this.rel_hum = rel_hum;
	}
	
	
}