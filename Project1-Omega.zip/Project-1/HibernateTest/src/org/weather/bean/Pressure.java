package org.weather.bean;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "_pressure")
public class Pressure implements Serializable{
	
	@Id
	@GeneratedValue
	@Column(name = "uniqueid")
	private long uniqueid;

	@Column(name = "pressure")
	private Float pressure;

	@Column(name = "altimeter")
	private Float altimeter;	
	
	public long getUniqueId() {
		return uniqueid;
	}

	public void setUniqueId(long uniqueid) {
		this.uniqueid = uniqueid;
	}

	public Float getPressure() {
		return pressure;
	}

	public void setPressure(Float pressure) {
		this.pressure = pressure;
	}

	public Float getAltimeter() {
		return altimeter;
	}

	public void setAltimeter(Float altimeter) {
		this.altimeter = altimeter;
	}

}