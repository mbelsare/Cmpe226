package org.weather.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "_wind")
public class Wind implements Serializable{
	@Id
	@Column(name = "uniqueid")
	private long uniqueid;

	@Column(name = "speed")
	private Float speed;

	@Column(name = "direction")
	private Float direction;

	@Column(name = "gust")
	private Float gust;

	public long getUniqueId() {
		return uniqueid;
	}

	public void setUniqueId(long uniqueid) {
		 this.uniqueid = uniqueid;
	}
	public void setSpeed(Float speed) {
		this.speed = speed;
	}

	public Float getSpeed() {
		return speed;
	}

	public void setDirection(Float direction) {
		this.direction = direction;
	}

	public Float getDirection() {
		return direction;
	}
	
	public void setGust(Float gust) {
		this.gust = gust;
	}

	public Float getGust() {
		return gust;
	}
		
}