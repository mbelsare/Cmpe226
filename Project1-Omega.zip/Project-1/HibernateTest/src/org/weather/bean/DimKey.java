package org.weather.bean;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Time;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "_dim_key")
public class DimKey implements Serializable{
	@Id
	@Column(name = "unique_id")
	private long uniqueid;

	@Column(name = "stn_id")
	private String stn_id;

	@Column(name = "_date")
	private Date date;

	@Column(name = "_time")
	private Time time;
	
	@OneToOne(fetch=FetchType.LAZY)
	@PrimaryKeyJoinColumn
	private Temperature temperature;
	
	@OneToOne(fetch=FetchType.LAZY)
	@PrimaryKeyJoinColumn
	private Humidity humidity;
	
	@OneToOne(fetch=FetchType.LAZY)
	@PrimaryKeyJoinColumn
	private Precipitation precipitation;
	
	@OneToOne(fetch=FetchType.LAZY)
	@PrimaryKeyJoinColumn
	private Pressure pressure;
	
	@OneToOne(fetch=FetchType.LAZY)
	@PrimaryKeyJoinColumn
	private Wind wind;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn (name="_time" ,referencedColumnName="timeOfday" , insertable=false,updatable=false)
	private TimeDimension timeDim;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn (name="_date" ,referencedColumnName="day_id" , insertable=false,updatable=false)
	private DateDimension dateDim;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn (name="stn_id" ,referencedColumnName="primary_id" , insertable=false,updatable=false)
	private Location location;

	public long getUniqueId() {
		return uniqueid;
	}

	public void setUniqueId(long uniqueid) {
		 this.uniqueid = uniqueid;
	}
	
	public String getStn_id() {
		return stn_id;
	}

	public void setStn_id(String stn_id) {
		this.stn_id = stn_id;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Date getDate() {
		return date;
	}
	
	public Time getTime() {
		return time;
	}

	public void setTime(Time time) {
		this.time = time;
	}
	
	public Location getLocation() {
		return location;
	}
	public void setLocation(Location location) {
		this.location = location;
	}
	public Temperature getTemperature() {  
        return temperature;  
    }  
    public void setTemperature(Temperature temp) {  
        this.temperature = temp;  
    }  

	public Humidity getHumidity() {
		return humidity;
	}
	public void setHumidity(Humidity humidity) {
		this.humidity = humidity;
	}
	public Precipitation getPrecipitation() {
		return precipitation;
	}
	public void setPrecipitation(Precipitation precipitation) {
		this.precipitation = precipitation;
	}
	public Pressure getPressure() {
		return pressure;
	}
	public void setPressure(Pressure pressure) {
		this.pressure = pressure;
	}
	public Wind getWind() {
		return wind;
	}

	public void setWind(Wind wind) {
		this.wind = wind;
	}
		
}