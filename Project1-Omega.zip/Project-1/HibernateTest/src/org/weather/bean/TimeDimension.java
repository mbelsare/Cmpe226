package org.weather.bean;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;

import org.hibernate.annotations.Type;

@Entity
@Table(name="_dim_time")
public class TimeDimension {
	@Id
	@Type(type="time")
	private Date timeOfDay;
	
	@Column(name="hour")
	private double hour;
	
	@Column(name="quarterhour")
	private String quarterhour;
	
	@Column(name="minute")
	private double minute;
	
	@Column(name="daytimename")
	private String dayTimeName;
	
	@Column(name="daynight")
	private String dayNight;
	
	@OneToMany(fetch=FetchType.LAZY)
	@JoinColumn (name="_time",referencedColumnName="timeofday",insertable=false,updatable=false)
	private List<DimKey> key;
	
	public Date getTimeOfDay() {
		return timeOfDay;
	}

	public void setTimeOfDay(Date timeOfDay) {
		this.timeOfDay = timeOfDay;
	}

	public double getHour() {
		return hour;
	}

	public void setHour(double hour) {
		this.hour = hour;
	}

	public String getQuarterhour() {
		return quarterhour;
	}

	public void setQuarterhour(String quarterhour) {
		this.quarterhour = quarterhour;
	}

	public double getMinute() {
		return minute;
	}

	public void setMinute(double minute) {
		this.minute = minute;
	}

	public String getDayTimeName() {
		return dayTimeName;
	}

	public void setDayTimeName(String dayTimeName) {
		this.dayTimeName = dayTimeName;
	}

	public String getDayNight() {
		return dayNight;
	}

	public void setDayNight(String dayNight) {
		this.dayNight = dayNight;
	}

	
}
