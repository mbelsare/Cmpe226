package org.weather.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "_temp")
public class Temperature implements Serializable{
	@Id
	@Column(name = "uniqueid")
	private long uniqueid;

	@Column(name = "temp")
	private Float temp;

	
	public long getUniqueId() {
		return uniqueid;
	}

	public void setUniqueId(long uniqueid) {
		 this.uniqueid = uniqueid;
	}
	public void settemp(Float temp) {
		this.temp = temp;
	}

	public Float getTemp() {
		return temp;
	}

		
}