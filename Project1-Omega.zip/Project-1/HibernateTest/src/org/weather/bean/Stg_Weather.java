package org.weather.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.sql.Time;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;

@Entity
@Table(name = "stg_weather")
public class Stg_Weather implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "row_id", updatable = false, nullable = false)
	private Long rowId;
	@Column(name="stn")
	private String station_id;
	@Column(name="_date")
	private Date date;
	@Column(name="_time")
	private Time time;
	@Column(name="mnet")
	private Double mnet;
	@Column(name="slat")
	private Double slat;
	@Column(name="slon")
	private Double slon;
	@Column(name="selv")
	private Double selv;
	@Column(name="tmpf")
	private Double tmpf;
	@Column(name="sknt")
	private Double sknt;
	@Column(name="drct")
	private Double drct;
	@Column(name="gust")
	private Double gust;
	@Column(name="pmsl")
	private Double pmsl;
	@Column(name="alti")
	private Double alti;
	@Column(name="dwpf")
	private Double dwpf;
	@Column(name="relh")
	private Double relh;
	@Column(name="wthr")
	private Double wthr;
	@Column(name="p24i")
	private Double p24i;	
	
	
	private Long getRowId() {
		return rowId;
	}
	private void setRowId(Long rowId) {
		this.rowId = rowId;
	}
	
	public String getStation_id() {
		return station_id;
	}
	public void setStation_id(String station_id) {
		this.station_id = station_id;
	}
	
	public Date getDate() {
		return date;
	}
	public void setDate(String sDate) {
		//System.out.println("date " + sDate);
		try{
			java.util.Date dateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(sDate);
			this.date = new java.sql.Date(dateTime.getTime());
			//System.out.println("date " + this.date);
		} catch(ParseException pe){
			System.out.println("Cannot parse the date.");
			pe.getStackTrace();
		}
	}

	public Time getTime() {
		return time;
	}
	
	public void setTime(String sTime) {
		try{
			java.util.Date dateTime= new SimpleDateFormat("HH:mm:ss").parse(sTime);
			this.time = new java.sql.Time(dateTime.getTime());

		} catch(ParseException pe){
			System.out.println("Cannot parse the time.");
			pe.getStackTrace();
		}
	}
	
	public double getMnet() {
		return mnet;
	}

	public void setMnet(String mnet) {
		this.mnet = Double.parseDouble(mnet);
	}
	
	public double getSlat() {
		return slat;
	}
	public void setSlat(String slat) {
		this.slat = Double.parseDouble(slat);
	}
	
	public double getSlon() {
		return slon;
	}
	public void setSlon(String slon) {
		this.slon = Double.parseDouble(slon);
	}
	
	public double getSelv() {
		return selv;
	}
	public void setSelv(String selv) {
		this.selv = Double.parseDouble(selv);
	}
	
	public double getTmpf() {
		return tmpf;
	}

	public void setTmpf(String tmpf) {
		String nullStr = "-9999.00";
		if((tmpf == null) || tmpf.equals(nullStr)){
			this.tmpf = null;
		}
		else{
			try{
				this.tmpf = Double.parseDouble(tmpf);
			}catch(NullPointerException ne){
				this.tmpf = null;
			}catch(NumberFormatException nfe){
				System.out.println("cannot parse the tmpf value!!");
				nfe.getStackTrace();
			}
		}		
	}
	
	public double getSknt() {
		return sknt;
	}
	public void setSknt(String sknt) {
		String nullStr = "-9999.00";
		if((sknt == null) || sknt.equals(nullStr)){
			this.sknt = null;
		}
		else{
			try{
				this.sknt = Double.parseDouble(sknt);
			}catch(NullPointerException ne){
				this.sknt = null;
			}catch(NumberFormatException nfe){
				System.out.println("cannot parse the sknt value!!");
				nfe.getStackTrace();
			}
		}

	}
	
	public double getDrct() {
		return drct;
	}
	public void setDrct(String drct) {
		String nullStr = "-9999.00";
		if((drct == null) || drct.equals(nullStr)){
			this.drct = null;
		}
		else{
			try{
				this.drct = Double.parseDouble(drct);
			}catch(NullPointerException ne){
				this.drct = null;
			}catch(NumberFormatException nfe){
				System.out.println("cannot parse the drct value!!");
				nfe.getStackTrace();
			}
		}
	}
	
	public double getGust() {
		return gust;
	}
	public void setGust(String gust) {
		String nullStr = "-9999.00";
		if((gust == null) || gust.equals(nullStr)){
			this.gust = null;
		}
		else{
			try{
				this.gust = Double.parseDouble(gust);
			}catch(NullPointerException ne){
				this.gust = null;
			}catch(NumberFormatException nfe){
				System.out.println("cannot parse the gust value!!");
				nfe.getStackTrace();
			}
		}
	}
	
	public double getPmsl() {
		return pmsl;
	}
	public void setPmsl(String pmsl) {
		String nullStr = "-9999.00";
		if((pmsl == null) || pmsl.equals(nullStr)){
			this.pmsl = null;
		}
		else{
			try{
				this.pmsl = Double.parseDouble(pmsl);
			}catch(NullPointerException ne){
				this.pmsl = null;
			}catch(NumberFormatException nfe){
				System.out.println("cannot parse the pmsl value!!");
				nfe.getStackTrace();
			}
		}

	}
	
	public double getAlti() {
		return alti;
	}
	public void setAlti(String alti) {
		String nullStr = "-9999.00";
		if((alti == null) || alti.equals(nullStr)){
			this.alti = null;
		}
		else{
			try{
				this.alti = Double.parseDouble(alti);
			}catch(NullPointerException ne){
				this.alti = null;
			}catch(NumberFormatException nfe){
				System.out.println("cannot parse the alti value!!");
				nfe.getStackTrace();
			}
		}

	}
	
	public double getDwpf() {
		return dwpf;
	}
	public void setDwpf(String dwpf) {
		String nullStr = "-9999.00";
		if((dwpf == null) ||dwpf.equals(nullStr)){
			this.dwpf = null;
		}
		else{
			try{
				this.dwpf = Double.parseDouble(dwpf);
			}catch(NullPointerException ne){
				this.dwpf = null;
			}catch(NumberFormatException nfe){
				System.out.println("cannot parse the dwpf value!!");
				nfe.getStackTrace();
			}
		}

	}
	
	public double getRelh() {
		return relh;
	}
	public void setRelh(String relh) {
		String nullStr = "-9999.00";
		if((relh == null) || relh.equals(nullStr)){
			this.relh = null;
		}
		else{
			try{
				this.relh = Double.parseDouble(relh);
			}catch(NullPointerException ne){
				this.relh = null;
			}catch(NumberFormatException nfe){
				System.out.println("cannot parse the relh value!!");
				nfe.getStackTrace();
			}
		}

	}
	
	public double getWthr() {
		return wthr;
	}
	public void setWthr(String wthr) {
		String nullStr = "-9999.00";
		if((wthr == null) || wthr.equals(nullStr)){
			this.wthr = null;
		}
		else{
			try{
				this.wthr = Double.parseDouble(wthr);
			}catch(NullPointerException ne){
				this.wthr = null;
			}catch(NumberFormatException nfe){
				System.out.println("cannot parse the wthr value!!");
				nfe.getStackTrace();
			}
		}

	}
	
	public double getP24i() {
		return p24i;
	}
	public void setP24i(String p24i) {
		String nullStr = "-9999.00";
		//System.out.println("p24i " + p24i);
		if((p24i == null) || p24i.equals(nullStr)){
			this.p24i = null;
		}
		else{
			try{
				this.p24i = Double.parseDouble(p24i);
			}catch(NullPointerException ne){
				this.p24i = null;
			}catch(NumberFormatException nfe){
				System.out.println("cannot parse the p24i value!!");
				nfe.getStackTrace();
			}
		}
	}


	
}
