package org.weather.bean;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "_dim_date")
public class DateDimension {
	@Id
	@Column(name="day_id")
	@Type(type="date")
	private Date dayId;	
	
	@Column(name = "_year")
	private short year;
	
	@Column(name = "_month")
	private short month;
	
	@Column(name = "_day")
	private short day;
	
	@Column(name = "quarter")
	private short quarter;
	
	@Column(name = "day_of_week")
	private short dayOfWeek;
	
	@Column(name = "day_of_year")
	private short dayOfYear;
	
	@Column(name = "week_of_year")
	private short weekOfyear;
	
	@OneToMany(fetch=FetchType.LAZY)
	@JoinColumn (name="_date",referencedColumnName="day_id",insertable=false,updatable=false)
	private List<DimKey> key;
	
	public Date getDayId() {
		return dayId;
	}

	public void setDayId(Date dayId) {
		this.dayId = dayId;
	}

	public int getYear() {
		return year;
	}

	public void setYear(short year) {
		this.year = year;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(short month) {
		this.month = month;
	}

	public int getDay() {
		return day;
	}

	public void setDay(short day) {
		this.day = day;
	}

	public int getQuarter() {
		return quarter;
	}

	public void setQuarter(short quarter) {
		this.quarter = quarter;
	}

	public int getDayOfWeek() {
		return dayOfWeek;
	}

	public void setDayOfWeek(short dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}

	public int getDayOfYear() {
		return dayOfYear;
	}

	public void setDayOfYear(short dayOfYear) {
		this.dayOfYear = dayOfYear;
	}

	public int getWeekOfyear() {
		return weekOfyear;
	}

	public void setWeekOfyear(short weekOfyear) {
		this.weekOfyear = weekOfyear;
	}

	
}
