package org.weather.bean;


import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "_precip")
public class Precipitation implements Serializable{
	@Id
	@GeneratedValue
	@Column(name = "uniqueid")
	private long uniqueid;

	@Column(name = "p24i")
	private Double p24i;
	
	
	public long getUniqueId() {
		return uniqueid;
	}

	public void setUniqueId(long uniqueid) {
		this.uniqueid = uniqueid;
	}

	public Double getP24i() {
		return p24i;
	}

	public void setP24i(Double p24i) {
		this.p24i = p24i;
	}


}