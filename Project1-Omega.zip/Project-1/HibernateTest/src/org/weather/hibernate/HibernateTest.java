package org.weather.hibernate;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.hql.internal.ast.ASTQueryTranslatorFactory;
import org.hibernate.hql.internal.ast.QueryTranslatorImpl;
import org.hibernate.hql.spi.QueryTranslatorFactory;
import org.weather.bean.DimKey;
import org.weather.bean.Location;



public class HibernateTest {
	
	@SuppressWarnings("unchecked")
	public void getStationsByState() throws Exception{
		
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		try {
			System.out.println("Get stations by state: " );
			session.beginTransaction();
			long start = System.currentTimeMillis();
			Query query = session.createQuery("from DimKey k where k.stn_id='BULLF'");
			List<DimKey> ls = (List<DimKey>) query.list();
			for(DimKey d : ls){
				System.out.println(d.getStn_id() + "\t" + d.getLocation().getStation_name() +
						"\t" + d.getLocation().getState());
			}		
			
			session.getTransaction().commit();
			long finish = System.currentTimeMillis();
			System.out.println("No of rows returned- " + ls.size() );
			System.out.println("Total time taken: " + (finish-start));
		} catch (Exception e) {
			session.getTransaction().rollback();
			throw e;
		}		
	}


	
	public void getStationByMaxTemp() throws Exception{
		
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		try {
			int count =0;
			session.beginTransaction();
			long start = System.currentTimeMillis();
			Query query = session.createQuery("from DimKey k where k.temperature.temp>200");
			List<DimKey> l = (List<DimKey>) query.list();
			for(DimKey d : l){
				count++;
				System.out.println(d.getStn_id() + "\t" +d.getLocation().getStation_name() +
						"\t"+ d.getDate() +"\t"+d.getTemperature().getTemp());
			
			}		
			
			session.getTransaction().commit();
			long finish = System.currentTimeMillis();
			System.out.println("No of rows returned- " + count );
			System.out.println("Total time taken: " + (finish-start));
		} catch (Exception e) {
			session.getTransaction().rollback();
			throw e;
		}		
	}

	public void getTempStatistics() throws Exception{
		
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		System.out.println("1. Get max, min and avg temp for all stations in a state, for a given date: " );
		try {
			session.beginTransaction();
			long start = System.currentTimeMillis();
			Query query = session.createQuery("select k.location.stn_id, k.location.station_name, " +
					"MAX(k.temperature.temp), MIN(k.temperature.temp), AVG(k.temperature.temp) " +
					"from DimKey k where k.date = '2013-08-29' and k.location.state = 'CA' " +
					" GROUP BY 1,2");
			
			List ls = query.list();
			Iterator itr = ls.iterator();
			while(itr.hasNext()){
				Object obj[]=(Object[])itr.next();
				System.out.println( obj[0] + "\t" + obj[1] + "\t" + obj[2] + "\t" + obj[3] + "\t" + obj[4]  );
			}
			
			session.getTransaction().commit();
			long finish = System.currentTimeMillis();
			System.out.println("No of rows returned- " + ls.size() );
			System.out.println("Total time taken: " + (finish-start));
		} catch (Exception e) {
			session.getTransaction().rollback();
			throw e;
		}				
	}
	
	public void getStationByRain() throws Exception{
		
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		System.out.println("3. Get stations in a state by morning rains: " );
		try {
			int count =0;
			session.beginTransaction();
			long start = System.currentTimeMillis();
			Query query = session.createQuery("from DimKey k where k.precipitation.p24i>0.1 and " +
					"k.timeDim.dayTimeName='Morning' and " +
					"k.date = '2013-08-29' and k.location.state='CA'");
			List<DimKey> l = (List<DimKey>) query.list();
			System.out.println("No of rows returned- " + l.size() );
			for(DimKey d : l){
				
				count++;
				System.out.println(d.getStn_id() + "\t" +d.getLocation().getStation_name() +
						"\t" + d.getDate() +"\t"+d.getPrecipitation().getP24i());			
			}		
			
			session.getTransaction().commit();
			long finish = System.currentTimeMillis();
			System.out.println("No of rows returned- " + count );
			System.out.println("Total time taken: " + (finish-start));
		} catch (Exception e) {
			session.getTransaction().rollback();
			throw e;
		}				
	}
	
	public void getStationsByWind() throws Exception{
		
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		System.out.println("4. Get stations by wind gust >= 33  and it's direction: " );
		try {
			session.beginTransaction();
			long start = System.currentTimeMillis();
			Query query = session.createQuery("from DimKey k where k.wind.gust>=33 and " +
					"k.date = '2013-08-29' and k.location.state='CA'");
			List<DimKey> l = (List<DimKey>) query.list();
			for(DimKey d : l){
				System.out.println(d.getStn_id() +"\t" +d.getLocation().getStation_name() +
						"\t"+ d.getDate() +"\t"+d.getWind().getGust()
						+","+d.getWind().getDirection());			
			}			
			session.getTransaction().commit();
			long finish = System.currentTimeMillis();
			System.out.println("No of rows returned- " + l.size() );
			System.out.println("Total time taken: " + (finish-start));
		} catch (Exception e) {
			session.getTransaction().rollback();
			throw e;
		}		
	}
	
	public void getAvgTempOfStations() throws Exception{
		
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		System.out.println("5. Get avg morning temperature and relative humidity of stations : " );
		try {
			session.beginTransaction();
			long start = System.currentTimeMillis();
			Query query = session.createQuery("select k.location.stn_id, k.location.station_name, k.date, AVG(k.humidity.rel_hum), " +
					"AVG(k.temperature.temp) from DimKey k where k.location.state='CA' and " +
					"k.date = '2013-08-29' " +
					"and k.timeDim.dayTimeName='Morning' and k.location.state='CA' GROUP BY 1,2,3");
			
			List ls = query.list();
			Iterator itr = ls.iterator();
			while(itr.hasNext()){
				Object obj[]=(Object[])itr.next();
				System.out.println( obj[0] + "\t" + obj[1] + "\t" + obj[2] + "\t" + obj[3] + "\t" + obj[4]  );
			}
			
			session.getTransaction().commit();
			long finish = System.currentTimeMillis();
			System.out.println("No of rows returned- " + ls.size() );
			System.out.println("Total time taken: " + (finish-start));
		} catch (Exception e) {
			session.getTransaction().rollback();
			throw e;
		}		
	}
	
	public void getWeekendsByRain() throws Exception{
		
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		System.out.println("6. Get stations by rains in the weekends : " );
		try {
			session.beginTransaction();
			long start = System.currentTimeMillis();
			Query query = session.createQuery("from DimKey k where k.precipitation.p24i>0.1 and " +
					"k.timeDim.dayTimeName='Morning' and k.dateDim.dayOfWeek IN (0,6) and" +
					" k.location.state='CA'");
			
			List<DimKey> l = (List<DimKey>) query.list();
			for(DimKey d : l){
			
				System.out.println(d.getStn_id() +"\t" +d.getLocation().getStation_name() +
						"\t"+ d.getDate() + "\t" + d.getPrecipitation().getP24i());			
			}		
			session.getTransaction().commit();
			long finish = System.currentTimeMillis();
			System.out.println("No of rows returned- " + l.size() );
			System.out.println("Total time taken: " + (finish-start));
		} catch (Exception e) {
			session.getTransaction().rollback();
			throw e;
		}		
	}

	public void getAvgDayTemp() throws Exception{
		
		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		System.out.println("7. Get avg temp of stations by date : " );
		try {
			session.beginTransaction();
			long start = System.currentTimeMillis();
			Query query = session.createQuery("select k.location.stn_id, k.location.station_name, " +
					"k.date, AVG(k.temperature.temp) " +
					"from DimKey k where k.date = '2013-08-29' and" +
					" k.location.state='CA' GROUP BY 1,2,3");
			
			List ls = query.list();
			Iterator itr = ls.iterator();
			while(itr.hasNext()){
				Object obj[]=(Object[])itr.next();
				System.out.println( obj[0] + "\t" + obj[1] + "\t" + obj[2] + "\t" + obj[3] );
			}		
			session.getTransaction().commit();
			long finish = System.currentTimeMillis();
			System.out.println("No of rows returned- " + ls.size() );
			System.out.println("Total time taken: " + (finish-start));
		} catch (Exception e) {
			session.getTransaction().rollback();
			throw e;
		}		
	}

	
}
