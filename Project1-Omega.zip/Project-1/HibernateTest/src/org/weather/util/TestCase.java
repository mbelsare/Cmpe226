package org.weather.util;

import java.util.List;

import org.weather.bean.DimKey;
import org.weather.bean.Location;
import org.weather.bean.Temperature;
import org.weather.hibernate.HibernateTest;

public class TestCase {

	/**
	 * @param args
	 */
	private static HibernateTest appObj = new HibernateTest();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			//appObj.getStationsByState();
			appObj.getTempStatistics();
			//appObj.getStationByRain();
			//appObj.getStationsByWind();
			//appObj.getAvgTempOfStations();
			//appObj.getWeekendsByRain();
			//appObj.getAvgDayTemp();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
