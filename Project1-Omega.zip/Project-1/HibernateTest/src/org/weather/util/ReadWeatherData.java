package org.weather.util;

import java.io.File;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;


import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.jdbc.Work;
import org.weather.hibernate.*;

public class ReadWeatherData {
	
	private static String _logentry;
	private static Logger logger;
    private static FileHandler fh; 
    private static SimpleFormatter formatter;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if (args.length != 1) {
			System.err.println("No input for data dir path!!!");
			System.exit(1);
		}

		String dirName = args[0];
		
		long start = System.currentTimeMillis();
		
		processFiles(dirName);

		long end = System.currentTimeMillis();
		long total = end - start;
		System.out.println("Total time taken: " + total/1000 + "secs");

	}
	
	private static void processFiles(String filePath) {
		logger = Logger.getLogger("MyLog");
		formatter = new SimpleFormatter(); 
		String logFile = filePath + "\\MyLogFile.log";
		try{
			fh = new FileHandler(logFile);  
			logger.addHandler(fh);
	        fh.setFormatter(formatter);  
		}
		catch (SecurityException e) {  
	        e.printStackTrace();  
	    } catch (IOException e) {  
	        e.printStackTrace();  
	    }  
		_logentry="No, Datetime, FileLoad, dim_key, temp, wind, humidity, pressure,precip\n";
		String dirName = filePath + "\\Data";
		performStaging(dirName);		
	}

	
	private  static void performStaging(String dirName){
		
		File directory = new File(dirName);
		CsvLoader loader = new CsvLoader();
		
		Date _date=new Date();
		int count = 1;
		int noOfLines = 0;
		
		if(!directory.exists()){
            System.out.println("No Data dir found");
            return;
		}
		if(directory.isDirectory()){
			
			System.out.println("No.of files found: " + directory.listFiles().length);

            for(File file :directory.listFiles()){
            	if (file.isFile()){
            		String filePath = dirName + "\\" + file.getName();
            		//System.out.println("File path: " + filePath);
            		_date=new Date();
    				_logentry=Integer.toString(count)+","+ _date.toString() + ",";

            		long start = System.currentTimeMillis();
            		try {
            			
            			noOfLines = loader.loadCSV(filePath, "stg_weather", false);
            		} catch (Exception e) {
            			// TODO Auto-generated catch block
            			//System.out.println("Error uploading .csv file - " + file.getName());
            			e.printStackTrace();
            		}
            		long end = System.currentTimeMillis();
            		long total = end - start;
            		_logentry=_logentry + Long.toString(end-start) + ","; 
            		//System.out.println("Filename: " + filePath);
            		//System.out.println("Time taken: " + total/1000 + "secs");
            		insertKeys();
            		count++;
            	}
            }
        }
	}
	
	// calling stored procedures to insert into db tables

	
	private  static void insertKeys(){
		
		long start = System.currentTimeMillis();
		
		String sQuery = "select * from _2_1_mesowest_insert_dim_key()";
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		session.doWork(new Work() {
            @Override
            public void execute(Connection conn) throws SQLException {
                  PreparedStatement pStmt = null;
                  //System.out.println("inside execute " + conn.isClosed());
                  try
                  {
                      String sqlQry = "select * from _2_1_mesowest_insert_dim_key()";
                      pStmt = conn.prepareStatement(sqlQry);
                      pStmt.execute();
                  }
                  finally
                  {
                      pStmt.close();
                  }                                
            }
		});
		tx.commit();

		long end = System.currentTimeMillis();
		_logentry=_logentry + Long.toString(end-start) + ","; 
		//System.out.println("Total Time taken to insert keys "+ (end-start) + "ms");
		insertIntoTemp();		
		
	}
	

	private  static void insertIntoTemp(){
		long start = System.currentTimeMillis();
		
		String sQuery = "{select * from  _2_2_mesowest_insert_temp()}";
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		session.doWork(new Work() {
            @Override
            public void execute(Connection conn) throws SQLException {
                  PreparedStatement pStmt = null;
                  try
                  {
                      String sqlQry = "select * from _2_2_mesowest_insert_temp()";
                      pStmt = conn.prepareStatement(sqlQry);
                      pStmt.execute();
                  }
                  finally
                  {
                      pStmt.close();
                  }                                
            }
		});
		tx.commit();

		long end = System.currentTimeMillis();
		_logentry=_logentry + Long.toString(end-start) + ","; 
		//System.out.println("Total Time taken to insert temp "+ (end-start) + "ms");

		insertIntoWind();
	}
	
	private  static void insertIntoWind(){
		
		long start = System.currentTimeMillis();
		
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		session.doWork(new Work() {
            @Override
            public void execute(Connection conn) throws SQLException {
                  PreparedStatement pStmt = null;
                  try
                  {
                      String sqlQry = "select * from _2_3_mesowest_insert_wind()";
                      pStmt = conn.prepareStatement(sqlQry);
                      pStmt.execute();
                  }
                  finally
                  {
                      pStmt.close();
                  }                                
            }
		});
		tx.commit();
		long end = System.currentTimeMillis();
		_logentry=_logentry + Long.toString(end-start) + ","; 
		//System.out.println("Total Time taken to insert wind "+ (end-start) + "ms");
		insertIntoHumidity();
	}
	
	private  static void insertIntoHumidity(){
		long start = System.currentTimeMillis();
		
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		session.doWork(new Work() {
            @Override
            public void execute(Connection conn) throws SQLException {
                  PreparedStatement pStmt = null;
                  try
                  {
                      String sqlQry = "select * from _2_4_mesowest_insert_humidity()";
                      pStmt = conn.prepareStatement(sqlQry);
                      pStmt.execute();
                  }
                  finally
                  {
                      pStmt.close();
                  }                                
            }
		});
		tx.commit();
		
		long end = System.currentTimeMillis();
		_logentry=_logentry + Long.toString(end-start) + ","; 
		//System.out.println("Total Time taken to insert humidity "+ (end-start) + "ms");

		insertIntoPressure();
	}

	private  static void insertIntoPressure(){
		long start = System.currentTimeMillis();
		
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		session.doWork(new Work() {
            @Override
            public void execute(Connection conn) throws SQLException {
                  PreparedStatement pStmt = null;
                  try
                  {
                      String sqlQry = "select * from _2_5_mesowest_insert_pressure()";
                      pStmt = conn.prepareStatement(sqlQry);
                      pStmt.execute();
                  }
                  finally
                  {
                      pStmt.close();
                  }                                
            }
		});
		tx.commit();

		long end = System.currentTimeMillis();
		_logentry=_logentry + Long.toString(end-start) + ","; 
		//System.out.println("Total Time taken to insert pressure "+ (end-start) + "ms");

		insertIntoPrecipitation();
	}

	private  static void insertIntoPrecipitation(){
		long start = System.currentTimeMillis();
		
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		session.doWork(new Work() {
            @Override
            public void execute(Connection conn) throws SQLException {
                  PreparedStatement pStmt = null;
                  try
                  {
                      String sqlQry = "select * from _2_6_mesowest_insert_precip()";
                      pStmt = conn.prepareStatement(sqlQry);
                      pStmt.execute();
                  }
                  finally
                  {
                      pStmt.close();
                  }                                
            }
		});
		tx.commit();

		long end = System.currentTimeMillis();
		_logentry=_logentry + Long.toString(end-start) + "\n"; 
		logger.info(_logentry);
		//System.out.println("Total Time taken to insert precipitation "+ (end-start) + "ms");

		
	}
}
	
	
