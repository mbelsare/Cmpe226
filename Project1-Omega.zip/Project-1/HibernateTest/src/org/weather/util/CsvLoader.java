package org.weather.util;


import java.io.FileReader;
import java.io.FileNotFoundException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.weather.bean.Stg_Weather;
import org.weather.bean.Weather;
import org.weather.hibernate.*;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.bean.ColumnPositionMappingStrategy;
import au.com.bytecode.opencsv.bean.CsvToBean;
 
public class CsvLoader{	
 
    private char separator;
    private ColumnPositionMappingStrategy<Weather> mappingStrategy;
    private String[] columns = new String[] {"station_id","date","time","mnet","slat","slon","selv","tmpf","sknt","drct","gust","pmsl",
    		"alti","dwpf","relh","wthr","p24i"};
    /**
     * Public constructor to build CSVLoader object with
     * Connection details. The connection is closed on success
     * or failure.
     * @param connection
     */
    public CsvLoader() {
        //Set default separator
        this.separator = ',';
        mappingStrategy = new ColumnPositionMappingStrategy<Weather>();
    }
     
    /**
     * Parse CSV file using OpenCSV library and load in 
     * given database table. 
     * @param csvFile Input CSV file
     * @param tableName Database table name to import data
     * @param truncateBeforeLoad Truncate the table before inserting 
     *          new records.
     * @throws Exception
     */
    public int loadCSV(String csvFile, String tableName,
            boolean truncateBeforeLoad) throws Exception {
    	
    	//System.out.println("Filename: " + csvFile);
    	//System.out.println("Tablename: " + tableName);

    	int noOfLines = 0;

    	mappingStrategy.setType(Weather.class);
    	mappingStrategy.setColumnMapping(columns);
    	CsvToBean<Weather> csv = new CsvToBean<Weather>();
    	List<Weather> list = null;
    	Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();


    	try {
             
            //System.out.println("Inside csv loader");
            CSVReader csvReader = new CSVReader(new FileReader(csvFile), this.separator);
            list = csv.parse(mappingStrategy, csvReader);
        } catch (Exception e){
        	e.printStackTrace();
        	throw new Exception("Error occured while parsing .csv file."
                    + e.getMessage());
        }
 
    	noOfLines = list.size();
       
        try {
            final int batchSize = 50;
            int count = 1;
            
            for (Weather data : list ) {           	
            	

            	if( data != null){
            		//System.out.println("Inside batch :" + data.getStation_id());
            		Stg_Weather wData = new Stg_Weather();
            		wData.setStation_id(data.getStation_id());
            		String dTime = data.getDate() + " " + data.getTime();
            		wData.setDate(dTime);
            		wData.setTime(data.getTime());
            		wData.setMnet(data.getMnet());
            		wData.setSlat(data.getSlat());
            		wData.setSlon(data.getSlon());
            		wData.setSelv(data.getSelv());
            		wData.setTmpf(data.getTmpf());
            		wData.setSknt(data.getSknt());
            		wData.setDrct(data.getDrct());
            		wData.setGust(data.getGust());
            		wData.setPmsl(data.getPmsl());
            		wData.setAlti(data.getAlti());
            		wData.setDwpf(data.getDwpf());
            		wData.setRelh(data.getRelh());
            		wData.setWthr(data.getWthr());
            		wData.setP24i(data.getP24i());
	            	session.save(wData);

	            	if (++count % batchSize == 0) {
	            		session.flush();
		            	session.clear();
	            	}
            	}
            	else
            		System.out.println("no data found after .csv file parsing - " + csvFile);
            }

            tx.commit();
        } catch (HibernateException e) {
	    	if(tx != null)
	    		tx.rollback();
	    	e.printStackTrace();	    	
	    } finally {
            //session.close();
        }
        
        return noOfLines;
    }
 
    public char getSeparator() {
        return separator;
    }
 
    public void setSeprator(char separator) {
        this.separator = separator;
    }
 
}