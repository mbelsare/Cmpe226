package org.weather.test;

public class JDBCTestUtil {
	
	private static JdbcTest test = new JdbcTest();
	
	public static void main(String args[]){
		JdbcTest test = new JdbcTest();
		test.findStations();
		//test.station_gust();
		//test.find_weekend_rain();
		//test.mean_Temp_Humidity();
		//test.Stations_P24I();
		//test.avg_Temp_Morning_Night();
		//test.find_windDirectionChange();
		//test.find_StationsWithinRadius();
	}
	
	
}
