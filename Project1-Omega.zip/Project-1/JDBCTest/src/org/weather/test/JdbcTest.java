package org.weather.test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.weather.*;

import com.weather.TestMain;

public class JdbcTest {

	private static Connection conn  =  ConnectionUtil.getCon();
	
	/*Finds the min max and avg temperature of stations 
	 * in that particular state for a particular date */
	public void findStations() {
		int count = 0;
		String sql = "Select DL.station_name, DK._date, max(TC.temp), min(TC.temp), avg(TC.temp) "
				+ "from  _temp TC, _dim_location DL, _dim_key DK WHERE "
				+ " DL.state='CA' and "
				+ " DL.primary_id=DK.stn_id and "
				+ " DK.unique_id=TC.uniqueid and "
				+ " DK._date = '2013-08-29' "
				+ " Group by 1, 2 "
				+ " ORDER BY 1, 2";

		try {
			Statement stmnt = conn.createStatement();
			long start = System.currentTimeMillis();
			ResultSet result = stmnt.executeQuery(sql);
			while (result.next()) {
				String s = result.getString(1);
				Date d = result.getDate(2);
				double max = result.getDouble(3);
				double min = result.getDouble(4);
				double avg = result.getDouble(5);
				count++;
				System.out.println(s +", "+d+", "+max+", " + min + ", "+ avg);
			}
			long end = System.currentTimeMillis();
			System.out.println("Number of rows fetched " + count);
			System.out.println("Total time taken" + (end - start));
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
		
	/* Find all stations in a state where rained in the morning */
	public void Stations_P24I() {
		int count = 0;
		String sql = "SELECT L.station_name, K.stn_id, K._date, AVG(P.p24i) "
				+ " FROM _dim_key K, _dim_time T, _precip P, _dim_location L "
				+ " WHERE "
				+ " T.daytimename='Morning' AND "
				+ " K._time=T.timeofday AND "
				+ " K._date = '2013-08-29'::date AND "
				+ " K.stn_id=L.primary_id AND P.uniqueid=K.unique_id "
				+ " AND L.state='CA' AND P.p24i>0.1 GROUP BY 1, 2,3";

		try {
			Statement stmnt = conn.createStatement();
			long start = System.currentTimeMillis();
			ResultSet result = stmnt.executeQuery(sql);
			while (result.next()) {
				String s1 = result.getString(1);
				String s2 = result.getString(2);
				Date d = result.getDate(3);
				double avg = result.getDouble(4);
				count++;
				System.out.println(s1 +", "+ s2 + ", "+ d + ", " + avg + ", ");
			}
			long end = System.currentTimeMillis();
			System.out.println("Number of rows fetched " + count);
			System.out.println("Total time taken" + (end - start));
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}	
		
	/*
	 * Find stations where the wind gust>=33 knots and the direction of wind at
	 * that speed... Need to test this properly
	 */
	public void station_gust() {
		int count = 0;
		String sql = " select d.stn_id ,W.speed, W.gust, _mesowest_drct(W.direction) "
				+ " from _dim_key d, _wind  w where d.unique_id=w.uniqueid AND w.gust>33 AND "
				+ " d._date = '2013-08-29' ::date";
		try {
			Statement stmnt = conn.createStatement();
			long start = System.currentTimeMillis();
			ResultSet result = stmnt.executeQuery(sql);
			while (result.next()) {
				String id  = result.getString(1);
				double speed = result.getDouble(2);
				double gust = result.getDouble(3);
				
				count++;
			}
			long end = System.currentTimeMillis();
			System.out.println("Number of rows fetched " + count);
			System.out.println("Total time taken" + (end - start));
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	public void mean_Temp_Humidity(){
		int count = 0;
		String sql = " select K.stn_id, L.station_name, K._date, AVG(H.rel_hum), AVG(T.temp) " +
		"from _temp T, _dim_key K, _humidity H, _dim_location L where " +
		" T.uniqueid=K.unique_id AND H.uniqueid=K.unique_id AND " +
		" L.primary_id=K.stn_id AND K._time='09:00:00'::time without time zone " +
		" AND L.state='CA' AND K._date = '2013-08-29'::date " +
		" AND '2013-09-16'::date GROUP BY 1, 2,3 ";
		try {
			Statement stmnt = conn.createStatement();
			long start = System.currentTimeMillis();
			ResultSet result = stmnt.executeQuery(sql);
			while (result.next()) {
				String id = result.getString(1);
				String name = result.getString(2);
				Date d = result.getDate(3);
				double avgHum = result.getDouble(4);
				double avgTmp = result.getDouble(5);
				System.out.println(id +", "+ name + ", "+ d + ", " + avgHum + ", "+ avgTmp);
				count++;
			}
			long end = System.currentTimeMillis();
			System.out.println("Number of rows fetched " + count);
			System.out.println("Total time taken" + (end - start));
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	//Find all weekends when it rained
	public void find_weekend_rain(){
		int count = 0;
		String sql = " select K._date, K.stn_id from " + 
		" _precip P, _dim_key K ,_dim_date D, _dim_time T where " + 
		" P.uniqueid=K.unique_id AND " +
		" K._date=D.day_id AND K._time=T.timeofday AND  T.daytimename='Morning' " +  
		" AND D.day_of_week IN (0,6) AND P.p24i>0.1 ";
		try {
			Statement stmnt = conn.createStatement();
			long start = System.currentTimeMillis();
			ResultSet result = stmnt.executeQuery(sql);
			while (result.next()) {
				Date d  = result.getDate(1);
				String s = result.getString(2);
				System.out.println(d +", "+ s);
				count++;
			}
			long end = System.currentTimeMillis();
			System.out.println("Number of rows fetched " + count);
			System.out.println("Total time taken" + (end - start));
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void avg_Temp_Morning_Night(){
		int count = 0;
		String sql = "SELECT L.station_name, K.stn_id, K._date,TM.daytimename, AVG(T.temp) "+
		"FROM _dim_key K, _dim_time TM,_dim_location L, _temp T " +
		" WHERE K._date = '2013-08-29'::date AND " +
		" TM.timeofday=K._time AND K.stn_id=L.primary_id AND " +
		"T.uniqueid=K.unique_id AND L.state='CA' GROUP BY 1, 2,3,4 ";
		try {
			Statement stmnt = conn.createStatement();
			long start = System.currentTimeMillis();
			ResultSet result = stmnt.executeQuery(sql);
			while (result.next()) {
				String s1  = result.getString(1);
				String s2 = result.getString(2);
				Date d  = result.getDate(3);
				String s3 = result.getString(4);
				double avgTmp = result.getDouble(5);
				System.out.println(s1 +", "+ s2 +", "+ d +", "+ s3 +", " + avgTmp);
				count++;
			}
			long end = System.currentTimeMillis();
			System.out.println("Number of rows fetched " + count);
			System.out.println("Total time taken" + (end - start));
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	//YOU NEED TO CHCK
	public void find_windDirectionChange(){
		int count = 0;
		String sql = "select L.station_name, K._date, T.daytimename, " +
    "round(SQRT(POWER(avg(W.speed*sin(RADIANS(W.direction))),2)+ POWER(avg(W.speed*cos(RADIANS(W.direction))),2))::numeric,2), " +
    "_mesowest_drct(round((DEGREES(ATAN(avg(W.speed*sin(RADIANS(W.direction))) / avg(W.speed*(cos(RADIANS(W.direction))+0.0001))))+360)::numeric,2)) "+
    " from _dim_location L, _dim_key K, _dim_time T, _wind W WHERE " +
	" K.unique_id=W.uniqueid AND K.stn_id=L.primary_id AND " +
	" K._time=T.timeofday AND L.state='CA' AND W.direction>0 AND W.speed>0 AND " +
	" K._date = '2013-08-29'::date " + 
	" GROUP BY L.station_name, K._date, T.daytimename " +
	" ORDER BY L.station_name, K._date" ;
			
		try {
			Statement stmnt = conn.createStatement();
			long start = System.currentTimeMillis();
			ResultSet result = stmnt.executeQuery(sql);
			while (result.next()) {
				String s1  = result.getString(1);
				Date d  = result.getDate(2);
				String s3 = result.getString(3);
				double avgDirct = result.getDouble(4);
				System.out.println(s1 +", " + d + ", "+ s3 +", " + avgDirct);
				count++;
			}
			long end = System.currentTimeMillis();
			System.out.println("Number of rows fetched " + count);
			System.out.println("Total time taken" + (end - start));
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void find_StationsWithinRadius(){
		
		int count = 0;
		String sql = "SELECT K._date,avg(T.temp),min(T.temp),max(T.temp) FROM " + 
	    "_dim_key K, _temp T,_dim_location L WHERE K.stn_id=L.primary_id AND " +
	    " K.unique_id=T.uniqueid AND " +
	    " K._date = '2013-08-29'::date AND " +
	    " L.geom && st_expand(st_transform(st_PointFromText('POINT(-121.92417 37.35917)', 4269),32661), 16093) AND " +
	    " st_distance(st_transform(st_PointFromText('POINT(-121.92417 37.35917)', 4269),32661),L.geom) < 16093 " +
	    " GROUP BY 1 " ;
			
		try {
			Statement stmnt = conn.createStatement();
			long start = System.currentTimeMillis();
			ResultSet result = stmnt.executeQuery(sql);
			while (result.next()) {
				Date d  = result.getDate(1);
				double avgTemp = result.getDouble(2);
				double minTemp = result.getDouble(3);
				double maxTemp = result.getDouble(4);
				System.out.println(d +", " + avgTemp + ", "+ minTemp +", " + maxTemp);
				count++;
			}
			long end = System.currentTimeMillis();
			System.out.println("Number of rows fetched " + count);
			System.out.println("Total time taken" + (end - start));
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
	

