package com.weather;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;


import au.com.bytecode.opencsv.CSV;
import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.bean.ColumnPositionMappingStrategy;
import au.com.bytecode.opencsv.bean.CsvToBean;


public class WeatherMain {
	private static ColumnPositionMappingStrategy<WeatherBean> strat; 
	private static final String columns [] ={"stn","mnet","slat","slon","selv",
    		"tmpf","sknt","drct","gust","pmsl","alti","dwpf","relh","wthr","p24i"};
	private static final String csvFileName ="C:\\Users\\Public\\withoutDate.txt";
	
	public static void main(String[] args) {
		loadCsv(csvFileName);
		}

	private static void loadCsv(String name) {
		try {
			strat = new ColumnPositionMappingStrategy<WeatherBean>();
			strat.setType(WeatherBean.class);
			strat.setColumnMapping(columns);
			CsvToBean<WeatherBean> csv = new CsvToBean<WeatherBean>();
			CSVReader csvreader = new CSVReader(new FileReader(csvFileName));
			List<WeatherBean> list = csv.parse(strat, csvreader);
			for(WeatherBean we : list){
				//WeatherBean we = (WeatherBean)object;
				System.out.println(we.getStn());
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		
	}

}
