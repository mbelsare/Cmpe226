package com.weather;
import java.io.File;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;


public class TestMain {
	private static final String JDBC_CONNECTION_URL= "jdbc:postgresql://localhost:5432/mesowest_weather";
	private static final String filePath="C:/Users/raul/Desktop/test/sep_9_15";
	private static CallableStatement stmt;
	private static Logger logger ;	
	private static FileHandler fh;
	static SimpleFormatter formatter;
	private static String _logentry;
	
	public static void main(String[] args) {
		processFiles();
	}
	
	private static void processFiles() {
		File []afiles = new File(filePath).listFiles();
		Date _date=new Date();
		int count = 1;
		logger = Logger.getLogger("MyLog");
		formatter = new SimpleFormatter(); 
		try{
			fh = new FileHandler("C:/Users/raul/Desktop/test/sep_9_15/benchmark.log");  
			logger.addHandler(fh);
	        fh.setFormatter(formatter);  
		}
		catch (SecurityException e) {  
	        e.printStackTrace();  
	    } catch (IOException e) {  
	        e.printStackTrace();  
	    }  
		_logentry="No, Datetime, FileLoad, dim_key, temp, wind, humidity, pressure,precip\n";
		for(File f : afiles){
			if(f.getName().matches("^mesowest(.*).txt$")){
				_date=new Date();
				_logentry=Integer.toString(count)+","+ _date.toString() + ",";
				performStaging(f.getName());
				count++;
			}
		}
		
	}
	//Perform batch upload into the database 
	private static void performStaging(String name) {
		CSVLoader loader = new CSVLoader(ConnectionUtil.getCon());
		try {
			long start = System.currentTimeMillis();
			loader.loadCSV(filePath+"/"+name, "stg_weather", false);
			long end = System.currentTimeMillis();
			System.out.println("Total time taken " + (end-start));
			_logentry=_logentry + Long.toString(end-start) + ",";
			 insertIntoMetaData();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	private static void insertIntoMetaData() {
			long start = System.currentTimeMillis();
			try {
				stmt = ConnectionUtil.getCon().prepareCall("{call _2_1_mesowest_insert_dim_key()}");
				stmt.execute();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			long end = System.currentTimeMillis();
			_logentry=_logentry + Long.toString(end-start) + ",";
			InsertIntoTemp();
		}

		private static void InsertIntoTemp() {
		
			long start = System.currentTimeMillis();
			try {
			  stmt = ConnectionUtil.getCon().prepareCall("{call _2_2_mesowest_insert_temp()}");
				stmt.execute();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			long end = System.currentTimeMillis();
			_logentry=_logentry + Long.toString(end-start) + ",";
			InsertIntoWind();
		}
		private static void InsertIntoWind() {
			long start = System.currentTimeMillis();
			try {
			stmt = ConnectionUtil.getCon().prepareCall("{call _2_3_mesowest_insert_wind()}");
			stmt.execute();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			long end = System.currentTimeMillis();
			_logentry=_logentry + Long.toString(end-start) + ","; 
			insertIntoHumidity();
		}
		
		private static void insertIntoHumidity() {
			long start = System.currentTimeMillis();
			try {
			 stmt = ConnectionUtil.getCon().prepareCall("{call _2_4_mesowest_insert_humidity()}");
			 stmt.execute();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			long end = System.currentTimeMillis();
			_logentry=_logentry + Long.toString(end-start) + ","; 
			insertIntoPressure();
		}
		
		private static void insertIntoPressure() {
			long start = System.currentTimeMillis();
			try {
			stmt = ConnectionUtil.getCon().prepareCall("{call _2_5_mesowest_insert_pressure()}");
			stmt.execute();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			long end = System.currentTimeMillis();
			_logentry=_logentry + Long.toString(end-start) + ","; 
			insertIntoPrecip();
		}
		
		private static void insertIntoPrecip() {
			long start = System.currentTimeMillis();
			try {
			stmt = ConnectionUtil.getCon().prepareCall("{call _2_6_mesowest_insert_precip()}");
			stmt.execute();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			long end = System.currentTimeMillis();
			_logentry=_logentry + Long.toString(end-start) + ","; 
			logger.info(_logentry);
			System.out.println(_logentry);
		}
		
}
