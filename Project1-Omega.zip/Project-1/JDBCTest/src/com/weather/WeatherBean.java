package com.weather;
import java.sql.Time;
import java.util.Date;


public class WeatherBean {
	
	private String stn;
	private double mnet;
	private String date;
	private String time;
	private double slat;
	private double slon;
	private double selv;
	private double tmpf;
	private double sknt;
	private double drct;
	private double gust;
	private double pmsl;
	private double alti;
	private double dwpf;
	private double relh;
	private double wthr;
	private String p24i;
	
	public String getStn() {
		return stn;
	}
	public void setStn(String stn) {
		this.stn = stn;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public double getMnet() {
		return mnet;
	}
	public void setMnet(double mnet) {
		this.mnet = mnet;
	}
	public double getSlat() {
		return slat;
	}
	public void setSlat(double slat) {
		this.slat = slat;
	}
	public double getSlon() {
		return slon;
	}
	public void setSlon(double slon) {
		this.slon = slon;
	}
	public double getSelv() {
		return selv;
	}
	public void setSelv(double selv) {
		this.selv = selv;
	}
	public double getTmpf() {
		return tmpf;
	}
	public void setTmpf(double tmpf) {
		this.tmpf = tmpf;
	}
	public double getSknt() {
		return sknt;
	}
	public void setSknt(double sknt) {
		this.sknt = sknt;
	}
	public double getDrct() {
		return drct;
	}
	public void setDrct(double drct) {
		this.drct = drct;
	}
	public double getGust() {
		return gust;
	}
	public void setGust(double gust) {
		this.gust = gust;
	}
	public double getPmsl() {
		return pmsl;
	}
	public void setPmsl(double pmsl) {
		this.pmsl = pmsl;
	}
	public double getAlti() {
		return alti;
	}
	public void setAlti(double alti) {
		this.alti = alti;
	}
	public double getDwpf() {
		return dwpf;
	}
	public void setDwpf(double dwpf) {
		this.dwpf = dwpf;
	}
	public double getRelh() {
		return relh;
	}
	public void setRelh(double relh) {
		this.relh = relh;
	}
	public double getWthr() {
		return wthr;
	}
	public void setWthr(double wthr) {
		this.wthr = wthr;
	}
	public String getP24i() {
		return p24i;
	}
	public void setP24i(String p24i) {
		this.p24i = p24i;
	}
}
