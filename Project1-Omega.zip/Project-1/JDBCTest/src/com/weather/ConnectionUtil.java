package com.weather;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionUtil {

	private static final String JDBC_CONNECTION_URL= "jdbc:postgresql://localhost:5432/mesowest_col";
	private static java.sql.Connection conn = null;
			
	public static java.sql.Connection getCon(){
				try {
					Class.forName("org.postgresql.Driver");
					conn =  DriverManager.getConnection(JDBC_CONNECTION_URL, "postgres","postgres");
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					e.printStackTrace();
				}	
				return conn;
			}
}
