package com.weather;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Time;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
//import org.apache.commons.lang.StringUtils;
import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.bean.ColumnPositionMappingStrategy;
import au.com.bytecode.opencsv.bean.CsvToBean;
 
public class CSVLoader {
 
    private static final String SQL_INSERT = "INSERT INTO stg_weather (stn,_date,_time,mnet,slat,slon,selv,tmpf,sknt,drct,gust,pmsl,alti,dwpf,relh,wthr,p24i) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String TABLE_REGEX = "\\$\\{table\\}";
    private static final String KEYS_REGEX = "\\$\\{keys\\}";
    private static final String VALUES_REGEX = "\\$\\{values\\}";
    private Connection connection;
    private char seprator;
    private ColumnPositionMappingStrategy<WeatherBean> strat;
    private String columns [] ={"stn","date","time","mnet","slat","slon","selv",
    		"tmpf","sknt","drct","gust","pmsl","alti","dwpf","relh","wthr","p24i"};
    /**
     * Public constructor to build CSVLoader object with
     * Connection details. The connection is closed on success
     * or failure.
     * @param connection
     */
    public CSVLoader(Connection connection) {
        this.connection = connection;
        //Set default separator
        this.seprator = ',';
        strat = new ColumnPositionMappingStrategy<WeatherBean>();
    }
     
    /**
     * Parse CSV file using OpenCSV library and load in 
     * given database table. 
     * @param csvFile Input CSV file
     * @param tableName Database table name to import data
     * @param truncateBeforeLoad Truncate the table before inserting 
     *          new records.
     * @throws Exception
     */
    public void loadCSV(String csvFile, String tableName,
            boolean truncateBeforeLoad) throws Exception {
    	strat.setType(WeatherBean.class);
        strat.setColumnMapping(columns);
    	CsvToBean<WeatherBean> csv = new CsvToBean<WeatherBean>();
    	CSVReader csvReader = null;
    	List<WeatherBean> list = null;
        if(null == this.connection) {
            throw new Exception("Not a valid connection.");
        }
        try {
             
            csvReader = new CSVReader(new FileReader(csvFile),seprator);
            System.out.println("Rahul");
            list = csv.parse(strat, csvReader);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Error occured while executing file. "
                    + e.getMessage());
        }
        String query = SQL_INSERT;
        System.out.println("Query: " + query);
 
        String[] nextLine;
        Connection con = null;
        PreparedStatement ps = null;
        
        try {
            con = this.connection;
            con.setAutoCommit(false);
            ps = con.prepareStatement(query);
 
            if(truncateBeforeLoad) {
                //delete data from table before loading csv
                con.createStatement().execute("DELETE FROM " + tableName);
            }
 
            final int batchSize = 500;
            int count = 0;
            Date date = null;
//            while ((nextLine = csvReader.readNext()) != null) {
//            	System.out.println(nextLine);
//                if (null != nextLine) {
                    int index = 1;
                    Date _startdate;
               	Date _enddate;
               	Date _datefromfile;
               	_startdate=new SimpleDateFormat("yyyy-MM-dd").parse("2013-09-09");
        		_enddate=new SimpleDateFormat("yyyy-MM-dd").parse("2013-09-15");
        		  for (WeatherBean we : list ) { 
        			  _datefromfile=new SimpleDateFormat("yyyy-MM-dd").parse(we.getDate());	
                      if(_datefromfile.compareTo(_startdate)>=0 && _datefromfile.compareTo(_enddate)<=0){   
        		ps.setString(1, we.getStn());
                DateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                Date d = dateformat.parse(we.getDate() + " " + we.getTime());
                    ps.setDate(2, new java.sql.Date(d.getTime()));
                    ps.setTime(3, new java.sql.Time(d.getTime()));
                    ps.setDouble(4, we.getMnet());
                    ps.setDouble(5, we.getSlat());
                    ps.setDouble(6, we.getSlon());
                    ps.setDouble(7, we.getSelv());
                    if(we.getTmpf() == -9999){
                    	ps.setNull(8,Types.DOUBLE);
                    }else{
                    	ps.setDouble(8, we.getTmpf());	
                    	}
                    
                     if(we.getSknt() == -9999 ){
                    	ps.setNull(9, Types.DOUBLE);
                    }else{
                    	ps.setDouble(9, we.getSknt());
                    }
                     
                     if(we.getDrct() == -9999){
                    	 ps.setNull(10, Types.DOUBLE);
                     }else{
                    	 ps.setDouble(10, we.getDrct());
                     }
                     
                     if(we.getGust() == -9999){
                    	 ps.setNull(11, Types.DOUBLE);
                     }else{
                    	 ps.setDouble(11, we.getGust());
                     }
                    
                     if(we.getPmsl() == -9999){
                    	 ps.setNull(12, Types.DOUBLE);
                     }else{
                    	 ps.setDouble(12, we.getPmsl());
                     }
                     
                     if(we.getAlti() == -9999){
                    	 ps.setNull(13, Types.DOUBLE);
                     }else{
                    	 ps.setDouble(13, we.getAlti());
                     }
                     
                     if(we.getDwpf() == -9999){
                    	 ps.setNull(14, Types.DOUBLE);
                     }else{
                    	 ps.setDouble(14, we.getDwpf());
                     }
                     
                     if(we.getRelh() == -9999){
                    	 ps.setNull(15, Types.DOUBLE);
                     }else{
                    	 ps.setDouble(15, we.getRelh());
                     }
                     
                     if(we.getWthr() == -9999){
                    	 ps.setNull(16, Types.DOUBLE);
                     }else{
                    	 ps.setDouble(16, we.getWthr());
                     }
                     
                     if(we.getP24i() == null || we.getP24i().equals("-9999.00")){
                    	 ps.setNull(17, Types.DOUBLE);
                    }else{
                    	ps.setDouble(17, Double.parseDouble(we.getP24i()));
                    } 
                     
             //        ps.execute();
                     ps.addBatch();  
                     if (++count % batchSize == 0) {
                     	//System.out.println("Insde batch");
                    	 ps.executeBatch();
                     }
                 }   
              }
            ps.executeBatch(); // insert remaining records
            con.commit();
        } catch (Exception e) {
            con.rollback();
            e.printStackTrace();
            throw new Exception(
                    "Error occured while loading data from file to database."
                            + e.getMessage());
        } finally {
            if (null != ps)
                ps.close();
            if (null != con)
                con.close();
 
            csvReader.close();
        }
    }
 
    public char getSeprator() {
        return seprator;
    }
 
    public void setSeprator(char seprator) {
        this.seprator = seprator;
    }
 
}